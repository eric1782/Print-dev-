import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Header from "./components/Header";
import Hero from "./components/Hero";
import QuienesSomos from "./pages/Landing/QuienesSomos";
import Servicios from "./pages/Landing/Servicios";
import Contacto from "./pages/Landing/Contacto";
import Footer from "./components/Footer";
import Login from "./pages/Login/Login";
import Registro from "./pages/Login/Registro";
import HomeUsuario from "./pages/Home/HomeUsuario"; 

function App() {
  return (
    <Router>
      <Routes>
        {/* Landing con header/footer */}
        <Route
          path="/"
          element={
            <>
              <Header />
              <Hero />
              <QuienesSomos />
              <Servicios />
              <Contacto />
              <Footer />
            </>
          }
        />
        <Route path="/login" element={<Login />} />
        <Route path="/registro" element={<Registro />} />
        <Route path="/home-usuario" element={<HomeUsuario />} /> {/* 👈 nuevo */}
      </Routes>
    </Router>
  );
}

export default App;
