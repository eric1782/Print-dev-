import Header from "./components/Header";
import Footer from "./components/Footer";
import ScrollToTop from "./components/ScrollToTop";
import HomeUsuario from "./pages/Home/HomeUsuario"; // Import HomeUsuario

function App() {
  return (
    <>
      <Header />
      <main className="pt-20">
        <HomeUsuario /> {/* Render HomeUsuario */}
      </main>
      <Footer />
      <ScrollToTop />
    </>
  );
}

export default App;







